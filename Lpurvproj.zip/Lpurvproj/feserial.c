#include <linux/init.h>
#include <linux/module.h>
#include <linux/platform_device.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/fs.h>
#include <linux/errno.h>
#include <linux/types.h>
#include <linux/fcntl.h>
/*
______LPuRV_Project_2023_____________________
______AUTHOR:_Milica_Simeunovic_RA93_2018____
*/

#include <linux/proc_fs.h>
#include <linux/string.h>
#include <linux/ioport.h>
#include <linux/ktime.h>
#include <linux/hrtimer.h>
#include <asm/io.h>
#include <linux/of.h>
#include <asm/uaccess.h>
#include <linux/pm_runtime.h>
#include <linux/clk.h>
#include <linux/amba/serial.h>
#include <linux/miscdevice.h>
#include <linux/interrupt.h>
#include <linux/spinlock.h>
#include <linux/of_irq.h>
 
#define BAUDRATE        115200
#define INT_BAUDRATE         0x24
#define FRACT_BAUDRATE         0x28
#define CONTROL_REG       0x30
#define DATA_REG       0x00
#define INTERRUPT_MASK_REG     0x38
#define FLAG_REG 0x18
#define BAUD_DIVISOR 16*BAUDRATE
 
#define MAX_SIZE        100
 
enum serial {SERIAL_RESET_COUNTER = 0, SERIAL_GET_COUNTER = 1};
static char *buff;
 
struct fserial_dev {
     	void __iomem   *regs;  
     	u8 gpio;                       /* GPIO pin that the LED is connected to */
	unsigned dev_address[2];
     	struct miscdevice miscdev;
     	int char_num;
     	wait_queue_head_t timer_wait;
     	int serial_buff_r;
     	int serial_buff_w;
     	int condition;
    	char character;
    	//spinlock_t lock;
    	int irq;
};

// Read from register 
static unsigned int reg_read(struct fserial_dev *dev, int offset)
{
    	return readl(dev->regs + offset);
}

// Write in register 
static void reg_write(struct fserial_dev *dev, int value, int offset)
{
    	writel(value, dev->regs + offset);
}
 
// Character write 
static void write_char(struct fserial_dev *fserial_ptr, char c)
{
    	// Check state of FIFO
   	u32 __iomem reg_value = reg_read(fserial_ptr, FLAG_REG);
	while(reg_value & (0x20))
	{
		cpu_relax();
		reg_value = reg_read(fserial_ptr, FLAG_REG);
	}
	// Write data
    	reg_write(fserial_ptr, c, DATA_REG);
}
 
 
 
static ssize_t feserial_write(struct file *f, const char __user *buf, size_t sz, loff_t *ppos)
{
	
	// Get driver data
	struct fserial_dev *fserial_ptr = container_of(f->private_data, struct fserial_dev, miscdev);
    
    	// Get data from userspace
	if (copy_from_user(buff, buf, strlen(buf)))
	{
		printk("Error write");
		return -1;
	}
    	
    	// Write output to UART
	int i;
	for(i = 0; i < sz; i++)
	{
		write_char(fserial_ptr, buff[i]);
        	fserial_ptr->char_num++;
    	}
    
	write_char(fserial_ptr, '\r');
 
    	return sz;
}   
 
 
 
static irqreturn_t fserial_dev(int irq, void *dev_id)
{
        u32 __iomem reg_val;
   	unsigned long f;
   	
        struct fserial_dev* fserial_ptr = (struct fserial_dev*)dev_id;
        
        //Reading DR clears interrupts
        reg_val = reg_read(fserial_ptr, DATA_REG);
        
        //Lock to avoid overlap
        //spin_lock_irqsave(&fserial_ptr->lock, f);
        
        //Get the data
        fserial_ptr->character = (reg_val & 0xFF);
        
        //Set condition for read
        fserial_ptr->condition = 1;
        
        //Unlock
        //spin_unlock_irqrestore(&fserial_ptr->lock, f);
 	
 	//Wake up read
        wake_up_interruptible(&fserial_ptr->timer_wait);
 
        return IRQ_HANDLED;
}
 
 
static ssize_t feserial_read(struct file *fl, char __user *buf, size_t sz, loff_t *ppos)
{
	int ret = 1;
	unsigned long f;
	
	// Get driver data
	struct fserial_dev *dev = container_of(fl->private_data, struct fserial_dev, miscdev);
	 
	// Wait for data    
	wait_event_interruptible(dev->timer_wait, dev->condition);
	
	// Lock to avoid overlap
	//spin_lock_irqsave(&dev->lock, f);
	
	// Output to user   
	if(copy_to_user(buf, &dev->character, sizeof(dev->character)))
	{
		printk(KERN_INFO "copy_from_user failed.\n");
		return -EINVAL;
	}
	
	// Reset condition for read 
	dev->condition = 0;
	
	// Unlock
	//spin_unlock_irqrestore(&dev->lock, f);
	 
	return ret;
 
}
 
            
long feserial_ioctl(struct file *f, unsigned int cmd, unsigned long arg)
{
    
	struct fserial_dev *fserial_ptr = container_of(f->private_data, struct fserial_dev, miscdev);
		    
	int c = (int)cmd;
	int ret;
		    
	switch(cmd){	    
		
		case SERIAL_RESET_COUNTER:			    
			ret = 0;
			fserial_ptr->char_num = 0;
			break;
		case SERIAL_GET_COUNTER:  
			ret = fserial_ptr->char_num;
			break;		
		default:
			printk("default"); 
				    
	}

	return ret;
}
 
     
static const struct file_operations feserial_fops = {
    .owner = THIS_MODULE,
    .write = feserial_write,
    .read = feserial_read,
    .unlocked_ioctl = feserial_ioctl,
};
 
 
 
static int feserial_probe(struct platform_device *pdev)
{
 
    int result = -1;
    
    // Allocate device driver memory
    struct fserial_dev *fserial_ptr = devm_kzalloc(&pdev->dev, sizeof(struct fserial_dev), GFP_KERNEL);
    if(!fserial_ptr) {
		dev_err(&pdev->dev, "ERROR: Memory is not allocated.\n");
		return -ENOMEM;
	}
	
    //Init
    buff = devm_kzalloc(&pdev->dev, sizeof(char), GFP_KERNEL);
    fserial_ptr->char_num = 0;
    
    
    //Proveravanje adrese
    struct resource *res;
    
    // Get the address of the device  
    res = platform_get_resource(pdev, IORESOURCE_MEM, 0);
    if(!res){
        return -EBUSY;
    }
 
    init_waitqueue_head(&fserial_ptr->timer_wait);
    //spin_lock_init(&fserial_ptr->lock);
    
    result = of_property_read_u32_array(pdev->dev.of_node, "reg", fserial_ptr->dev_address, 2);
 
    // Map physical address of the regs on virtual address 
    fserial_ptr->regs = devm_ioremap_resource(&pdev->dev, res);
    if (IS_ERR(fserial_ptr->regs))
        return PTR_ERR(fserial_ptr->regs);
        
 
    // Power management
    pm_runtime_enable(&pdev->dev);
    pm_runtime_get_sync(&pdev->dev);
 
    // Get device tree frequency funcion
    struct clk * uart_clk = devm_clk_get(&pdev->dev, NULL);
    if (!uart_clk) {
        dev_err(&pdev->dev, "Could not get uart0 clock.\n");
        return -EBUSY;
    }
    
    int clkrate = clk_get_rate(uart_clk);
    int baud_divisor = clkrate/16/BAUDRATE;
 
    int ret = clk_prepare_enable(uart_clk);
 
    if (ret) {
        dev_err(&pdev->dev, "Unable to enable uart0 clock\n");
        return ret;
    }
 
    // Disable UART
    int old_cr = reg_read(fserial_ptr, CONTROL_REG);
    reg_write(fserial_ptr, 0, CONTROL_REG);
    
    // Setting baudrate
    reg_write(fserial_ptr, baud_divisor, INT_BAUDRATE);
    reg_write(fserial_ptr, BAUD_DIVISOR, FRACT_BAUDRATE);
    
    // Enable UART and read-write
    //int old cr = reg_read(fserial_ptr, CONTROL_REG);
    reg_write(fserial_ptr, old_cr | 0x301, CONTROL_REG);
    
    write_char(fserial_ptr, 'M');
    write_char(fserial_ptr, '\n');
 
 
    u32 __iomem reg_value = reg_read(fserial_ptr, INTERRUPT_MASK_REG);
    reg_write(fserial_ptr, (reg_value | (0x10)), INTERRUPT_MASK_REG);
 
 
    fserial_ptr->irq = platform_get_irq(pdev, 0);
 
    result = devm_request_irq(&pdev->dev, fserial_ptr->irq, fserial_dev, 0, "feserial", fserial_ptr);
    if(result != 0)
    {
        printk(KERN_INFO "Could not request irq.\n");
        return result;
    }
 
 
    // Register misc device
    fserial_ptr->miscdev.fops = &feserial_fops;
    fserial_ptr->miscdev.name = "feserial";
    fserial_ptr->miscdev.minor = MISC_DYNAMIC_MINOR;
 
 
    result = misc_register(&fserial_ptr->miscdev);
 
    platform_set_drvdata(pdev, fserial_ptr);  
    pr_info("Called feserial_probe\n");  
    
    return 0;
};
 
 
static int feserial_remove(struct platform_device *pdev)
{   
    struct fserial_dev *fserial_ptr;
    
    // Get driver data
    fserial_ptr = platform_get_drvdata(pdev);
    
    // Disable power management
    pm_runtime_disable(&pdev->dev);
    
    // Deregister misc device
    misc_deregister(&fserial_ptr->miscdev);
    
    pr_info("Called feserial_remove\n");
 
    return 0;
}
 
static struct of_device_id feserial_dt_match[] = {
 
    { .compatible = "rtrk,serial" },
    { },
 
};
 
 
 
static struct platform_driver feserial_driver = {
        .driver = {
                .name = "feserial",
                .owner = THIS_MODULE,
                .of_match_table = of_match_ptr(feserial_dt_match),
        },
        .probe = feserial_probe,
        .remove = feserial_remove,
};
 
module_platform_driver(feserial_driver);
MODULE_LICENSE("GPL");
